var snowReports = [
  {
    "resort": "Cardrona",
    "country": "New Zealand",
    "report": "A blue bird day to day"
  },
  {
    "resort": "Treble Cone",
    "country": "New Zealand",
    "report": "Wall to wall sunshine"
  }
];

module.exports = snowReports;
